1. langkah-langkah membuat algoritma dalam menghitung luas dan keliling sebuah lingkaran
    Berikut ini adalah beberapa komponen yang dipakai dalam melakukan algoritma looping untuk menghitung luas dan keliling sebuah lingkaran:
    - Konstanta pi: adalah nilai konstan untuk menghitung luas dan keliling sebuah lingkaran. Nilai pi yang digunakan dalam contoh ini adalah 3.14
    - Variabel r (jari-jari): Variabel ini berfungsi untuk menyimpan value jari-jari lingkaran saat melakukan perulangan.
    - Perulangan for: Perulangan ini digunakan untuk melakukan perulangan.
    - Rumus luas lingkaran: Rumus untuk menghitung luas lingkaran, yaitu L = pi * r * r.
    - Rumus keliling lingkaran: Rumus untuk menghitung keliling lingkaran, yaitu K = 2 * pi * r.
    - Fungsi console.log(): untuk menampilkan hasil perhitungan luas dan keliling lingkaran.

2. contoh nilai input jari-jari untuk menghitung luas dan keliling lingkaran:
    data: input jari-jari = 7

3. Berikut adalah langkah-langkah algoritma untuk menghitung luas dan keliling lingkaran:
    -nyatakan nilai konstanta pi dengan nilai 3.14 atau 22/7 (contoh: const pi = 3.14;)
    -nyatakan nilai variabel jariJari lalu masukan nilai dari input 
    -Hitung luas lingkaran dengan rumus: L = pi * r * r
    -Hitung keliling lingkaran dengan rumus: K = 2 * pi * r
    -Tampilkan hasil perhitungan menggunakan console.log dengan keterangan " Luas sebuah lingkaran adalah : "